-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: crm_9
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(30) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `activity_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_lead_id_index` (`lead_id`),
  KEY `activities_user_id_index` (`user_id`),
  KEY `activities_type_index` (`type`),
  KEY `activities_activity_at_index` (`activity_at`),
  CONSTRAINT `activities_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,1,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(2,2,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(3,3,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(4,4,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(5,5,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(6,6,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(7,7,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-14 12:30:32','2026-11-14 05:30:32','2026-11-14 05:30:32'),(8,1,2,'status_change','Pendaftaran Pelatihan Berhasil - Otomatis Menjadi Customer','Peserta didaftarkan ke program pelatihan dan otomatis terkonversi menjadi Customer resmi (Kode: CUST-202611-0001).','2026-11-14 12:57:44','2026-11-14 05:57:44','2026-11-14 05:57:44'),(9,3,2,'status_change','Pendaftaran Pelatihan Berhasil - Otomatis Menjadi Customer','Peserta didaftarkan ke program pelatihan dan otomatis terkonversi menjadi Customer resmi (Kode: CUST-202611-0002).','2026-11-14 13:03:59','2026-11-14 06:03:59','2026-11-14 06:03:59'),(10,2,2,'note','Pendaftaran Peserta (Menunggu Pembayaran)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Akan resmi masuk ke Daftar Customer setelah pembayaran terkonfirmasi.','2026-11-14 15:10:53','2026-11-14 08:10:53','2026-11-14 08:10:53'),(11,4,2,'note','Pendaftaran Peserta (Menunggu Pembayaran)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Akan resmi masuk ke Daftar Customer setelah pembayaran terkonfirmasi.','2026-11-14 16:17:17','2026-11-14 09:17:17','2026-11-14 09:17:17'),(12,4,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-14 16:18:12','2026-11-14 09:18:12','2026-11-14 09:18:12'),(13,5,2,'note','Pendaftaran Peserta (Menunggu Pembayaran)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Akan resmi masuk ke Daftar Customer setelah pembayaran terkonfirmasi.','2026-11-14 16:55:52','2026-11-14 09:55:52','2026-11-14 09:55:52'),(14,5,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 1.831.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-14 16:56:22','2026-11-14 09:56:22','2026-11-14 09:56:22'),(15,8,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(16,9,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(17,10,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(18,11,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(19,12,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(20,13,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(21,14,3,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Sari Dewi sebagai Sales PIC.','2026-11-14 17:48:49','2026-11-14 10:48:49','2026-11-14 10:48:49'),(22,8,3,'note','Pendaftaran Peserta (Menunggu Pembayaran)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Akan resmi masuk ke Daftar Customer setelah pembayaran terkonfirmasi.','2026-11-14 19:20:57','2026-11-14 12:20:57','2026-11-14 12:20:57'),(23,8,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-14 19:26:33','2026-11-14 12:26:33','2026-11-14 12:26:33'),(24,15,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(25,16,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(26,17,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(27,18,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(28,19,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(29,20,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(30,21,4,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Andi Wijaya sebagai Sales PIC.','2026-11-15 02:34:27','2026-11-14 19:34:27','2026-11-14 19:34:27'),(31,15,4,'status_change','Pendaftaran Terkonfirmasi - Resmi Menjadi Customer','Peserta didaftarkan dengan status terkonfirmasi dan resmi masuk ke Daftar Customer (Kode: CUST-202611-0007).','2026-11-15 03:33:46','2026-11-14 20:33:46','2026-11-14 20:33:46'),(32,15,1,'status_change','Pembayaran Ditolak (Tidak Valid)','Pembayaran Rp 1.831.500 dinyatakan TIDAK VALID oleh admin. Alasan: \"bukti palsu\". Notifikasi telah dikirimkan ke akun sales penanggung jawab.','2026-11-15 03:43:53','2026-11-14 20:43:53','2026-11-14 20:43:53'),(33,15,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 1.831.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-15 03:44:38','2026-11-14 20:44:38','2026-11-14 20:44:38'),(34,15,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 1.831.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-15 03:44:47','2026-11-14 20:44:47','2026-11-14 20:44:47'),(35,16,2,'status_change','Status Diperbarui ke Ditolak (Lost)','Hasil follow-up dicatat: \"Respon prospek: Tidak Tertarik. Dapat di-follow up ulang di masa depan.\". Status prospek otomatis diperbarui menjadi Ditolak (Lost).','2026-11-15 04:02:06','2026-11-14 21:02:06','2026-11-14 21:02:06'),(36,17,4,'status_change','Status Diperbarui ke Ditolak (Lost)','Hasil follow-up dicatat: \"Respon prospek: Nomor Salah. Calon peserta dapat di-follow up ulang di masa mendatang.\". Status prospek otomatis diperbarui menjadi Ditolak (Lost).','2026-11-15 04:07:19','2026-11-14 21:07:19','2026-11-14 21:07:19'),(37,16,2,'status_change','Status Diperbarui ke Negosiasi','Hasil follow-up dicatat: \"Prospek sedang negosiasi penawaran harga.\". Status prospek otomatis diperbarui menjadi Negosiasi.','2026-11-15 04:15:38','2026-11-14 21:15:38','2026-11-14 21:15:38'),(38,16,2,'status_change','Status Diperbarui ke Ditolak (Lost)','Hasil follow-up dicatat: \"Respon prospek: Tidak Tertarik. Belum ada kebutuhan pelatihan saat ini.\". Status prospek otomatis diperbarui menjadi Ditolak (Lost).','2026-11-15 04:15:38','2026-11-14 21:15:38','2026-11-14 21:15:38'),(39,18,4,'status_change','Status Diperbarui ke Aktif','Hasil follow-up dicatat: \"Prospek berminat dan meminta informasi penawaran lebih lanjut.\". Status prospek otomatis diperbarui menjadi Aktif.','2026-11-15 04:22:29','2026-11-14 21:22:29','2026-11-14 21:22:29'),(40,18,4,'status_change','Pendaftaran Terkonfirmasi - Resmi Menjadi Customer','Peserta didaftarkan dengan status terkonfirmasi dan resmi masuk ke Daftar Customer (Kode: CUST-202611-0008).','2026-11-15 04:23:02','2026-11-14 21:23:02','2026-11-14 21:23:02'),(41,18,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-15 04:28:33','2026-11-14 21:28:33','2026-11-14 21:28:33'),(42,18,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-15 04:31:38','2026-11-14 21:31:38','2026-11-14 21:31:38'),(43,26,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(44,27,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(45,28,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(46,29,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(47,30,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(48,31,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(49,32,2,'note','Import Leads (Excel)','Prospek berhasil diimpor dari file Excel dan otomatis ditugaskan ke Budi Santoso sebagai Sales PIC.','2026-11-15 15:33:08','2026-11-15 08:33:08','2026-11-15 08:33:08'),(50,9,3,'status_change','Status Diperbarui ke Berhasil (Won)','Hasil follow-up dicatat: \"Closing berhasil! Calon peserta bersedia mendaftar.\". Status prospek otomatis diperbarui menjadi Berhasil (Won).','2026-11-15 15:42:10','2026-11-15 08:42:10','2026-11-15 08:42:10'),(51,9,3,'note','Pendaftaran Peserta (Menunggu Verifikasi Pembayaran Admin)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Status prospek akan resmi menjadi Berhasil (Closing) setelah pembayaran diverifikasi valid oleh admin.','2026-11-15 15:51:06','2026-11-15 08:51:06','2026-11-15 08:51:06'),(52,9,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-15 15:55:35','2026-11-15 08:55:35','2026-11-15 08:55:35'),(53,26,1,'admin_reminder','Instruksi Admin ke Budi Santoso','Mohon segera tindak lanjuti prospek \"Dimas Arya Pamungkas\" (WA: 081552334401) untuk penawaran program Program Pelatihan. Berikan detail materi dan jadwal pelatihan terdekat.','2026-11-16 07:07:01','2026-11-16 00:07:01','2026-11-16 00:07:01'),(54,26,2,'note','Pendaftaran Peserta (Menunggu Verifikasi Pembayaran Admin)','Calon peserta didaftarkan ke program pelatihan (Status: Registered). Status prospek akan resmi menjadi Berhasil (Closing) setelah pembayaran diverifikasi valid oleh admin.','2026-11-16 11:27:33','2026-11-16 04:27:33','2026-11-16 04:27:33'),(55,1,1,'status_change','Pembayaran Valid - Status diubah ke Berhasil (Won)','Pembayaran Rp 4.273.500 diverifikasi valid oleh admin. Pendaftaran peserta otomatis berstatus confirmed.','2026-11-16 11:28:11','2026-11-16 04:28:11','2026-11-16 04:28:11'),(56,26,2,'status_change','Status Diperbarui ke Ditolak (Lost)','Hasil follow-up dicatat: \"Respon prospek: Tidak Bersedia. Dapat di-follow up ulang di masa depan.\". Status prospek otomatis diperbarui menjadi Ditolak (Lost).','2026-11-16 11:29:41','2026-11-16 04:29:41','2026-11-16 04:29:41');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;

--
-- Table structure for table `cache`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cache_locks`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commissions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `lead_id` bigint(20) unsigned NOT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `deal_amount` decimal(15,2) NOT NULL,
  `commission_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `commission_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `bank_name` varchar(50) DEFAULT NULL,
  `bank_account_number` varchar(50) DEFAULT NULL,
  `bank_account_name` varchar(150) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `approved_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commissions_payment_id_foreign` (`payment_id`),
  KEY `commissions_user_id_index` (`user_id`),
  KEY `commissions_lead_id_index` (`lead_id`),
  KEY `commissions_status_index` (`status`),
  CONSTRAINT `commissions_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commissions_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `commissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commissions`
--

/*!40000 ALTER TABLE `commissions` DISABLE KEYS */;
INSERT INTO `commissions` VALUES (1,2,3,1,1831500.00,10.00,166500.00,'BCA','883019281','Budi Santoso','paid','2026-11-14 13:41:26','2026-11-14 20:41:00','81978000','2026-11-14 06:38:38','2026-11-14 07:10:02'),(2,2,2,10,4273500.00,10.00,388500.00,'BCA','883019281','Budi Santoso','paid','2026-11-14 15:53:35','2026-11-14 22:54:00',NULL,'2026-11-14 08:11:46','2026-11-14 08:54:34'),(3,2,4,11,4273500.00,10.00,388500.00,'BCA','883019281','Budi Santoso','paid','2026-11-14 16:18:53','2026-11-14 23:18:00','8889990000','2026-11-14 09:17:47','2026-11-14 09:19:09'),(4,2,5,12,1831500.00,10.00,166500.00,'BNI','883019281','Budi Santoso','paid','2026-11-14 17:12:06','2026-11-15 00:12:00',NULL,'2026-11-14 09:56:08','2026-11-14 10:12:12'),(5,3,8,13,4273500.00,10.00,388500.00,'Bank Mandiri','141002938192','Sari Dewi','paid','2026-11-14 19:21:39','2026-11-15 02:21:00',NULL,'2026-11-14 12:21:18','2026-11-14 12:21:42'),(7,4,15,14,1831500.00,10.00,166500.00,'BNI','0928371928','Andi Wijaya','paid','2026-11-15 03:44:59','2026-11-15 10:45:00',NULL,'2026-11-14 20:44:38','2026-11-14 20:45:02'),(8,4,18,15,4273500.00,10.00,388500.00,'BNI','0928371928','Andi Wijaya','paid','2026-11-15 04:32:09','2026-11-15 11:32:00',NULL,'2026-11-14 21:23:27','2026-11-14 21:32:21'),(9,3,9,16,4273500.00,10.00,388500.00,'Bank Mandiri','141002938192','Sari Dewi','paid','2026-11-15 15:55:47','2026-11-15 22:55:00',NULL,'2026-11-15 08:51:37','2026-11-15 08:56:07'),(10,2,1,17,4273500.00,10.00,388500.00,'BNI','883019281','Budi Santoso','paid','2026-11-16 11:28:20','2026-11-16 18:28:00',NULL,'2026-11-16 04:27:57','2026-11-16 04:28:24'),(12,2,4,19,976800.00,10.00,88800.00,'BNI','883019281','Budi Santoso','paid','2026-11-16 12:14:03','2026-11-16 19:14:00',NULL,'2026-11-16 05:12:42','2026-11-16 05:36:13'),(13,4,15,20,4273500.00,10.00,388500.00,'BNI','0928371928','Andi Wijaya','pending',NULL,NULL,NULL,'2026-11-22 08:04:16','2026-11-22 08:04:16');
/*!40000 ALTER TABLE `commissions` ENABLE KEYS */;

--
-- Table structure for table `customers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `nik` varchar(30) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `document_number` varchar(100) DEFAULT NULL,
  `institution_id` bigint(20) unsigned DEFAULT NULL,
  `lead_id` bigint(20) unsigned DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'active',
  `source` varchar(50) NOT NULL DEFAULT 'manual',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_customer_code_unique` (`customer_code`),
  KEY `customers_lead_id_foreign` (`lead_id`),
  KEY `customers_name_index` (`name`),
  KEY `customers_email_index` (`email`),
  KEY `customers_phone_index` (`phone`),
  KEY `customers_status_index` (`status`),
  KEY `customers_institution_id_index` (`institution_id`),
  CONSTRAINT `customers_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'CUST-202611-0001','Mochammad Rizky Pratama','rizky.pratama@jatimprov.go.id','081230112201','3578011204920001','1992-04-12','3578011204920001',5,1,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0001 (Program)','2026-11-14 05:57:44','2026-11-16 04:28:11',NULL),(2,'CUST-202611-0002','Hendra Gunawan','hendra.gunawan@surabaya.go.id','081230112203','3578032101900003','1990-01-21','3578032101900003',7,3,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0003 (Program)','2026-11-14 06:03:59','2026-11-14 06:03:59',NULL),(3,'CUST-202611-0003','Dwi Lestari Wulandari','dwi.lestari@pelindo.co.id','081230112202','3578025608940002','1994-08-16','3578025608940002',6,2,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0002 (Program)','2026-11-14 08:10:53','2026-11-14 09:06:25',NULL),(4,'CUST-202611-0004','Maya Anggraini','maya.anggraini@pln.co.id','081230112204','3578046709950004','1995-09-27','3578046709950004',8,4,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0004 (Program)','2026-11-14 09:17:17','2026-11-16 05:36:13',NULL),(5,'CUST-202611-0005','Bagus Setiawan','bagus.setiawan@kemendagri.go.id','081230112205','3578051803930005','1993-03-18','3578051803930005',9,5,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0005 (Program)','2026-11-14 09:55:52','2026-11-14 09:56:22',NULL),(6,'CUST-202611-0006','Fajar Ramadhan','fajar.ramadhan@bankmandiri.co.id','081331223301','3578081402920008','1992-02-14','3578081402920008',12,8,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0008 (Program)','2026-11-14 12:20:57','2026-11-14 12:26:33',NULL),(7,'CUST-202611-0007','Dimas Arya Pamungkas','dimas.arya@its.ac.id','081552334401','3578151908940015','1994-08-19','3578151908940015',19,15,'Surabaya','Jawa Timur','prospect','import_excel','Otomatis masuk dari Lead LDA-20261115-0001 (Program)','2026-11-14 20:33:46','2026-11-16 04:27:33',NULL),(8,'CUST-202611-0008','Anisa Rahmawati','anisa.rahmawati@unesa.ac.id','081552334404','3578184511970018','1997-11-05','3578184511970018',22,18,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261115-0004 (Program)','2026-11-14 21:23:02','2026-11-14 21:31:38',NULL),(9,'CUST-202611-0009','Nurul Hidayati','nurul.hidayati@rsudsoetomo.id','081331223302','3578095507950009','1995-07-15','3578095507950009',13,9,'Surabaya','Jawa Timur','active','import_excel','Otomatis masuk dari Lead LDA-20261114-0009 (Program)','2026-11-15 08:51:06','2026-11-15 08:55:35',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

--
-- Table structure for table `failed_jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `follow_ups`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `follow_ups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `assigned_to` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `follow_up_at` datetime NOT NULL,
  `method` varchar(30) NOT NULL DEFAULT 'whatsapp',
  `priority` varchar(20) NOT NULL DEFAULT 'normal',
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `result_notes` text DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `follow_ups_lead_id_index` (`lead_id`),
  KEY `follow_ups_assigned_to_index` (`assigned_to`),
  KEY `follow_ups_follow_up_at_index` (`follow_up_at`),
  KEY `follow_ups_status_index` (`status`),
  CONSTRAINT `follow_ups_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `follow_ups_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_ups`
--

/*!40000 ALTER TABLE `follow_ups` DISABLE KEYS */;
INSERT INTO `follow_ups` VALUES (1,15,4,'Follow-Up (WhatsApp) - Dimas Arya Pamungkas','mengingatkan kembali','2026-11-16 10:46:00','whatsapp','normal','completed','Otomatis selesai: Prospek telah berhasil (closing) / terdaftar program','2026-11-15 04:42:33','2026-11-14 20:49:06','2026-11-14 21:42:33'),(2,15,4,'Follow-Up (WhatsApp) - Dimas Arya Pamungkas','mengingatkan kembali','2026-11-16 10:49:00','whatsapp','normal','completed',NULL,'2026-11-15 03:50:43','2026-11-14 20:49:57','2026-11-14 20:50:43'),(3,16,4,'Follow-Up (WhatsApp) - Ratna Juwita',NULL,'2026-11-17 10:51:00','whatsapp','normal','completed','Respon prospek: Tidak Tertarik. Belum ada kebutuhan pelatihan saat ini.','2026-11-15 04:15:38','2026-11-14 20:51:08','2026-11-14 21:15:38'),(4,17,4,'Follow-Up (WhatsApp) - Kevin Sanjaya Putra',NULL,'2026-11-15 11:06:00','whatsapp','normal','completed','Respon prospek: Nomor Salah. Calon peserta dapat di-follow up ulang di masa mendatang.','2026-11-15 04:07:19','2026-11-14 21:07:06','2026-11-14 21:07:19'),(5,18,4,'Follow-Up (WhatsApp) - Anisa Rahmawati',NULL,'2026-11-16 11:21:00','whatsapp','normal','completed','Prospek berminat dan meminta informasi penawaran lebih lanjut.','2026-11-15 04:22:29','2026-11-14 21:22:02','2026-11-14 21:22:29'),(6,9,3,'Follow-Up (WhatsApp) - Nurul Hidayati',NULL,'2026-11-16 22:41:00','whatsapp','normal','completed','Closing berhasil! Calon peserta bersedia mendaftar.','2026-11-15 15:42:10','2026-11-15 08:41:24','2026-11-15 08:42:10'),(7,26,2,'Pengingat Follow-up Admin','Mohon segera tindak lanjuti prospek \"Dimas Arya Pamungkas\" (WA: 081552334401) untuk penawaran program Program Pelatihan. Berikan detail materi dan jadwal pelatihan terdekat.','2026-11-23 00:00:00','whatsapp','high','completed','Respon prospek: Tidak Bersedia. Dapat di-follow up ulang di masa depan.','2026-11-16 11:29:41','2026-11-16 00:07:01','2026-11-16 04:29:41'),(8,27,2,'Follow-Up (WhatsApp) - Ratna Juwita',NULL,'2026-11-16 18:28:00','whatsapp','normal','pending',NULL,NULL,'2026-11-16 04:28:58','2026-11-16 04:28:58');
/*!40000 ALTER TABLE `follow_ups` ENABLE KEYS */;

--
-- Table structure for table `import_batches`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `import_batches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `total_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `success_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_rows` int(10) unsigned NOT NULL DEFAULT 0,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `import_batches_status_index` (`status`),
  KEY `import_batches_user_id_index` (`user_id`),
  CONSTRAINT `import_batches_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_batches`
--

/*!40000 ALTER TABLE `import_batches` DISABLE KEYS */;
INSERT INTO `import_batches` VALUES (1,2,'leads_batch_1.xlsx','imports/Lqc0y8i7z675gDuQeAahHNwAJfMsHLctxesTKjoi.xlsx',7,7,0,'completed','2026-11-14 05:30:32','2026-11-14 05:30:32'),(2,3,'leads_batch_2.xlsx','imports/zDVka95rgzebv0nqOfiSQpOJmdA0a3axEGw6TioP.xlsx',7,7,0,'completed','2026-11-14 10:48:49','2026-11-14 10:48:49'),(3,4,'leads_batch_3.xlsx','imports/TvSKSeLReP4SF58j4aOOkRwateHtMeQvt8R2JLBg.xlsx',7,7,0,'completed','2026-11-14 19:34:27','2026-11-14 19:34:27'),(4,2,'leads_batch_3.xlsx','imports/emKDESaVaCCBA5J6RfDvEi3weyQYVD42UQbncjhK.xlsx',7,7,0,'completed','2026-11-15 08:33:08','2026-11-15 08:33:08');
/*!40000 ALTER TABLE `import_batches` ENABLE KEYS */;

--
-- Table structure for table `import_rows`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `import_rows` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `import_batch_id` bigint(20) unsigned NOT NULL,
  `row_number` int(10) unsigned NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `errors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`errors`)),
  `lead_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `import_rows_lead_id_foreign` (`lead_id`),
  KEY `import_rows_import_batch_id_status_index` (`import_batch_id`,`status`),
  CONSTRAINT `import_rows_import_batch_id_foreign` FOREIGN KEY (`import_batch_id`) REFERENCES `import_batches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `import_rows_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_rows`
--

/*!40000 ALTER TABLE `import_rows` DISABLE KEYS */;
INSERT INTO `import_rows` VALUES (1,1,2,'{\"name\":\"Mochammad Rizky Pratama\",\"phone\":\"081230112201\",\"email\":\"rizky.pratama@jatimprov.go.id\",\"company\":\"Bappeda Provinsi Jawa Timur\"}','imported',NULL,1,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(2,1,3,'{\"name\":\"Dwi Lestari Wulandari\",\"phone\":\"081230112202\",\"email\":\"dwi.lestari@pelindo.co.id\",\"company\":\"PT Pelabuhan Indonesia (Pelindo)\"}','imported',NULL,2,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(3,1,4,'{\"name\":\"Hendra Gunawan\",\"phone\":\"081230112203\",\"email\":\"hendra.gunawan@surabaya.go.id\",\"company\":\"Dinas Komunikasi dan Informatika Surabaya\"}','imported',NULL,3,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(4,1,5,'{\"name\":\"Maya Anggraini\",\"phone\":\"081230112204\",\"email\":\"maya.anggraini@pln.co.id\",\"company\":\"PT PLN (Persero) UID Jawa Timur\"}','imported',NULL,4,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(5,1,6,'{\"name\":\"Bagus Setiawan\",\"phone\":\"081230112205\",\"email\":\"bagus.setiawan@kemendagri.go.id\",\"company\":\"Balai Diklat Keagamaan Surabaya\"}','imported',NULL,5,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(6,1,7,'{\"name\":\"Rina Kusuma Dewi\",\"phone\":\"081230112206\",\"email\":\"rina.kusuma@telkom.co.id\",\"company\":\"PT Telkom Indonesia Witel Jatim\"}','imported',NULL,6,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(7,1,8,'{\"name\":\"Aditya Tri Nugroho\",\"phone\":\"081230112207\",\"email\":\"aditya.tri@pertamina.com\",\"company\":\"PT Pertamina Patra Niaga Jatimbalinus\"}','imported',NULL,7,'2026-11-14 05:30:32','2026-11-14 05:30:32'),(8,2,2,'{\"name\":\"Fajar Ramadhan\",\"phone\":\"081331223301\",\"email\":\"fajar.ramadhan@bankmandiri.co.id\",\"company\":\"Bank Mandiri Kantor Cabang Surabaya\"}','imported',NULL,8,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(9,2,3,'{\"name\":\"Nurul Hidayati\",\"phone\":\"081331223302\",\"email\":\"nurul.hidayati@rsudsoetomo.id\",\"company\":\"RSUD Dr. Soetomo Surabaya\"}','imported',NULL,9,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(10,2,4,'{\"name\":\"Arif Wicaksono\",\"phone\":\"081331223303\",\"email\":\"arif.wicaksono@bca.co.id\",\"company\":\"Bank Central Asia (BCA) KCU Darmo\"}','imported',NULL,10,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(11,2,5,'{\"name\":\"Dewi Sartika\",\"phone\":\"081331223304\",\"email\":\"dewi.sartika@bpjs-kesehatan.go.id\",\"company\":\"BPJS Kesehatan Cabang Surabaya\"}','imported',NULL,11,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(12,2,6,'{\"name\":\"Eko Prasetyo Utomo\",\"phone\":\"081331223305\",\"email\":\"eko.utomo@bankjatim.co.id\",\"company\":\"PT Bank Pembangunan Daerah Jawa Timur (Bank Jatim)\"}','imported',NULL,12,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(13,2,7,'{\"name\":\"Indah Permatasari\",\"phone\":\"081331223306\",\"email\":\"indah.permatasari@silooamhospitals.com\",\"company\":\"Siloam Hospitals Surabaya\"}','imported',NULL,13,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(14,2,8,'{\"name\":\"Wahyu Tri Hidayat\",\"phone\":\"081331223307\",\"email\":\"wahyu.hidayat@bni.co.id\",\"company\":\"PT Bank Negara Indonesia (Persero) Tbk\"}','imported',NULL,14,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(15,3,2,'{\"name\":\"Dimas Arya Pamungkas\",\"phone\":\"081552334401\",\"email\":\"dimas.arya@its.ac.id\",\"company\":\"Institut Teknologi Sepuluh Nopember (ITS)\"}','imported',NULL,15,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(16,3,3,'{\"name\":\"Ratna Juwita\",\"phone\":\"081552334402\",\"email\":\"ratna.juwita@unair.ac.id\",\"company\":\"Universitas Airlangga (UNAIR)\"}','imported',NULL,16,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(17,3,4,'{\"name\":\"Kevin Sanjaya Putra\",\"phone\":\"081552334403\",\"email\":\"kevin.sanjaya@wingscorp.com\",\"company\":\"PT Wings Surya Surabaya\"}','imported',NULL,17,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(18,3,5,'{\"name\":\"Anisa Rahmawati\",\"phone\":\"081552334404\",\"email\":\"anisa.rahmawati@unesa.ac.id\",\"company\":\"Universitas Negeri Surabaya (UNESA)\"}','imported',NULL,18,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(19,3,6,'{\"name\":\"Galang Fajar Kurnia\",\"phone\":\"081552334405\",\"email\":\"galang.fajar@maspion.com\",\"company\":\"Maspion Group Indonesia\"}','imported',NULL,19,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(20,3,7,'{\"name\":\"Putri Ayu Maharani\",\"phone\":\"081552334406\",\"email\":\"putri.ayu@ubaya.ac.id\",\"company\":\"Universitas Surabaya (UBAYA)\"}','imported',NULL,20,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(21,3,8,'{\"name\":\"Yudha Pratama Wicaksono\",\"phone\":\"081552334407\",\"email\":\"yudha.pratama@pakuwon.com\",\"company\":\"PT Pakuwon Jati Tbk\"}','imported',NULL,21,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(22,4,2,'{\"name\":\"Dimas Arya Pamungkas\",\"phone\":\"081552334401\",\"email\":\"dimas.arya@its.ac.id\",\"company\":\"Institut Teknologi Sepuluh Nopember (ITS)\"}','imported',NULL,26,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(23,4,3,'{\"name\":\"Ratna Juwita\",\"phone\":\"081552334402\",\"email\":\"ratna.juwita@unair.ac.id\",\"company\":\"Universitas Airlangga (UNAIR)\"}','imported',NULL,27,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(24,4,4,'{\"name\":\"Kevin Sanjaya Putra\",\"phone\":\"081552334403\",\"email\":\"kevin.sanjaya@wingscorp.com\",\"company\":\"PT Wings Surya Surabaya\"}','imported',NULL,28,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(25,4,5,'{\"name\":\"Anisa Rahmawati\",\"phone\":\"081552334404\",\"email\":\"anisa.rahmawati@unesa.ac.id\",\"company\":\"Universitas Negeri Surabaya (UNESA)\"}','imported',NULL,29,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(26,4,6,'{\"name\":\"Galang Fajar Kurnia\",\"phone\":\"081552334405\",\"email\":\"galang.fajar@maspion.com\",\"company\":\"Maspion Group Indonesia\"}','imported',NULL,30,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(27,4,7,'{\"name\":\"Putri Ayu Maharani\",\"phone\":\"081552334406\",\"email\":\"putri.ayu@ubaya.ac.id\",\"company\":\"Universitas Surabaya (UBAYA)\"}','imported',NULL,31,'2026-11-15 08:33:08','2026-11-15 08:33:08'),(28,4,8,'{\"name\":\"Yudha Pratama Wicaksono\",\"phone\":\"081552334407\",\"email\":\"yudha.pratama@pakuwon.com\",\"company\":\"PT Pakuwon Jati Tbk\"}','imported',NULL,32,'2026-11-15 08:33:08','2026-11-15 08:33:08');
/*!40000 ALTER TABLE `import_rows` ENABLE KEYS */;

--
-- Table structure for table `institutions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institutions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `industry` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institutions_name_index` (`name`),
  KEY `institutions_type_index` (`type`),
  KEY `institutions_city_index` (`city`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutions`
--

/*!40000 ALTER TABLE `institutions` DISABLE KEYS */;
INSERT INTO `institutions` VALUES (2,'PT Budi Maju','company',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-14 04:48:11','2026-11-14 04:48:11'),(3,'CV Budi Sejahtera','company',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-14 04:48:11','2026-11-14 04:48:11'),(4,'PT Sari Sukses','company',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-14 04:48:11','2026-11-14 04:48:11'),(5,'Bappeda Provinsi Jawa Timur','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(6,'PT Pelabuhan Indonesia (Pelindo)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(7,'Dinas Komunikasi dan Informatika Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(8,'PT PLN (Persero) UID Jawa Timur','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(9,'Balai Diklat Keagamaan Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(10,'PT Telkom Indonesia Witel Jatim','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(11,'PT Pertamina Patra Niaga Jatimbalinus','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 05:16:19','2026-11-14 05:16:19'),(12,'Bank Mandiri Kantor Cabang Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(13,'RSUD Dr. Soetomo Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(14,'Bank Central Asia (BCA) KCU Darmo','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(15,'BPJS Kesehatan Cabang Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(16,'PT Bank Pembangunan Daerah Jawa Timur (Bank Jatim)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(17,'Siloam Hospitals Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(18,'PT Bank Negara Indonesia (Persero) Tbk','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 10:48:49','2026-11-14 10:48:49'),(19,'Institut Teknologi Sepuluh Nopember (ITS)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(20,'Universitas Airlangga (UNAIR)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(21,'PT Wings Surya Surabaya','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(22,'Universitas Negeri Surabaya (UNESA)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(23,'Maspion Group Indonesia','company',NULL,NULL,'Sidoarjo, Jawa Timur','Sidoarjo','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(24,'Universitas Surabaya (UBAYA)','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27'),(25,'PT Pakuwon Jati Tbk','company',NULL,NULL,'Surabaya, Jawa Timur','Surabaya','Jawa Timur',NULL,NULL,'2026-11-14 19:34:27','2026-11-14 19:34:27');
/*!40000 ALTER TABLE `institutions` ENABLE KEYS */;

--
-- Table structure for table `job_batches`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lead_sources`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_sources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lead_sources_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_sources`
--

/*!40000 ALTER TABLE `lead_sources` DISABLE KEYS */;
INSERT INTO `lead_sources` VALUES (1,'manual','Input Manual',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(2,'import_excel','Import Excel',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(3,'import_csv','Import CSV',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(4,'website','Website',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(5,'whatsapp','WhatsApp',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55');
/*!40000 ALTER TABLE `lead_sources` ENABLE KEYS */;

--
-- Table structure for table `leads`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `whatsapp` varchar(50) DEFAULT NULL,
  `nik` varchar(30) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `lead_source_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `deal_price` decimal(15,2) DEFAULT NULL COMMENT 'Harga kesepakatan negosiasi sales dengan pelanggan',
  `assigned_to` bigint(20) unsigned DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'new',
  `rejection_reason_id` bigint(20) unsigned DEFAULT NULL,
  `rejection_notes` text DEFAULT NULL,
  `lead_score` int(10) unsigned NOT NULL DEFAULT 0,
  `priority` varchar(20) NOT NULL DEFAULT 'normal',
  `first_contacted_at` datetime DEFAULT NULL,
  `last_contacted_at` datetime DEFAULT NULL,
  `converted_at` datetime DEFAULT NULL,
  `lost_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `leads_lead_code_unique` (`lead_code`),
  KEY `leads_rejection_reason_id_foreign` (`rejection_reason_id`),
  KEY `leads_status_index` (`status`),
  KEY `leads_priority_index` (`priority`),
  KEY `leads_assigned_to_index` (`assigned_to`),
  KEY `leads_lead_source_id_index` (`lead_source_id`),
  KEY `leads_product_id_index` (`product_id`),
  KEY `leads_created_at_index` (`created_at`),
  CONSTRAINT `leads_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leads_lead_source_id_foreign` FOREIGN KEY (`lead_source_id`) REFERENCES `lead_sources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leads_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leads_rejection_reason_id_foreign` FOREIGN KEY (`rejection_reason_id`) REFERENCES `rejection_reasons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (1,'LDA-20261114-0001','Mochammad Rizky Pratama','rizky.pratama@jatimprov.go.id','081230112201','081230112201','3578011204920001','1992-04-12','Bappeda Provinsi Jawa Timur',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,2,'2026-11-14 12:30:32','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-16 11:28:11',NULL,'Prospek instansi pemprov, belum tentukan program minat','2026-11-14 05:30:32','2026-11-16 04:28:11',NULL),(2,'LDA-20261114-0002','Dwi Lestari Wulandari','dwi.lestari@pelindo.co.id','081230112202','081230112202','3578025608940002','1994-08-16','PT Pelabuhan Indonesia (Pelindo)',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,2,'2026-11-14 12:30:32','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-14 16:06:25',NULL,'Kebutuhan in-house training BUMN','2026-11-14 05:30:32','2026-11-14 09:06:25',NULL),(3,'LDA-20261114-0003','Hendra Gunawan','hendra.gunawan@surabaya.go.id','081230112203','081230112203','3578032101900003','1990-01-21','Dinas Komunikasi dan Informatika Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,2,1831500.00,2,'2026-11-14 12:30:32','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-14 13:03:59',NULL,'Follow up kebutuhan diklat staf','2026-11-14 05:30:32','2026-11-14 07:10:02',NULL),(4,'LDA-20261114-0004','Maya Anggraini','maya.anggraini@pln.co.id','081230112204','081230112204','3578046709950004','1995-09-27','PT PLN (Persero) UID Jawa Timur',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,2,'2026-11-14 12:30:32','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-14 16:18:12',NULL,'Menunggu penawaran katalog program terbaru','2026-11-14 05:30:32','2026-11-16 05:06:04',NULL),(5,'LDA-20261114-0005','Bagus Setiawan','bagus.setiawan@kemendagri.go.id','081230112205','081230112205','3578051803930005','1993-03-18','Balai Diklat Keagamaan Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,2,1831500.00,2,'2026-11-14 12:30:32','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-14 16:56:22',NULL,'Perlu konsultasi silabus materi pelatihan','2026-11-14 05:30:32','2026-11-14 09:56:22',NULL),(6,'LDA-20261114-0006','Rina Kusuma Dewi','rina.kusuma@telkom.co.id','081230112206','081230112206','3578064911960006','1996-11-09','PT Telkom Indonesia Witel Jatim',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-14 12:30:32','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Minta dikirimi proposal umum','2026-11-14 05:30:32','2026-11-14 05:30:32',NULL),(7,'LDA-20261114-0007','Aditya Tri Nugroho','aditya.tri@pertamina.com','081230112207','081230112207','3578070505910007','1991-05-05','PT Pertamina Patra Niaga Jatimbalinus',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-14 12:30:32','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Diskusi lanjutan jadwal ketersediaan kelas','2026-11-14 05:30:32','2026-11-14 05:30:32',NULL),(8,'LDA-20261114-0008','Fajar Ramadhan','fajar.ramadhan@bankmandiri.co.id','081331223301','081331223301','3578081402920008','1992-02-14','Bank Mandiri Kantor Cabang Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,3,'2026-11-14 17:48:49','won',NULL,NULL,0,'normal',NULL,NULL,'2026-11-14 19:26:33',NULL,'Eksplorasi pelatihan perbankan','2026-11-14 10:48:49','2026-11-14 12:26:33',NULL),(9,'LDA-20261114-0009','Nurul Hidayati','nurul.hidayati@rsudsoetomo.id','081331223302','081331223302','3578095507950009','1995-07-15','RSUD Dr. Soetomo Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,3,'2026-11-14 17:48:49','won',NULL,NULL,0,'normal','2026-11-15 15:42:10','2026-11-15 15:42:10','2026-11-15 15:55:35',NULL,'Rencana peningkatan mutu tenaga kesehatan','2026-11-14 10:48:49','2026-11-15 08:55:35',NULL),(10,'LDA-20261114-0010','Arif Wicaksono','arif.wicaksono@bca.co.id','081331223303','081331223303','3578101010890010','1989-10-10','Bank Central Asia (BCA) KCU Darmo',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,3,'2026-11-14 17:48:49','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Menunggu konfirmasi anggaran bagian HRD','2026-11-14 10:48:49','2026-11-14 10:48:49',NULL),(11,'LDA-20261114-0011','Dewi Sartika','dewi.sartika@bpjs-kesehatan.go.id','081331223304','081331223304','3578116204970011','1997-04-22','BPJS Kesehatan Cabang Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,3,'2026-11-14 17:48:49','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Kebutuhan pelatihan internal divisi operasional','2026-11-14 10:48:49','2026-11-14 10:48:49',NULL),(12,'LDA-20261114-0012','Eko Prasetyo Utomo','eko.utomo@bankjatim.co.id','081331223305','081331223305','3578120806930012','1993-06-08','PT Bank Pembangunan Daerah Jawa Timur (Bank Jatim)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,3,'2026-11-14 17:48:49','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Koordinasi awal via WhatsApp','2026-11-14 10:48:49','2026-11-14 10:48:49',NULL),(13,'LDA-20261114-0013','Indah Permatasari','indah.permatasari@silooamhospitals.com','081331223306','081331223306','3578134301980013','1998-01-03','Siloam Hospitals Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,3,'2026-11-14 17:48:49','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Minta info perbandingan program reguler vs private','2026-11-14 10:48:49','2026-11-14 10:48:49',NULL),(14,'LDA-20261114-0014','Wahyu Tri Hidayat','wahyu.hidayat@bni.co.id','081331223307','081331223307','3578142512900014','1990-12-25','PT Bank Negara Indonesia (Persero) Tbk',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,3,'2026-11-14 17:48:49','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Rencana pelatihan kuartal depan','2026-11-14 10:48:49','2026-11-14 10:48:49',NULL),(15,'LDA-20261115-0001','Dimas Arya Pamungkas','dimas.arya@its.ac.id','081552334401','081552334401','3578151908940015','1994-08-19','Institut Teknologi Sepuluh Nopember (ITS)',NULL,'Surabaya','Jawa Timur',NULL,2,2,1831500.00,4,'2026-11-15 02:34:27','won',NULL,NULL,0,'normal','2026-11-15 03:50:43','2026-11-15 03:50:43','2026-11-15 03:33:46',NULL,'Prospek kampus, menanyakan akreditasi pelatihan','2026-11-14 19:34:27','2026-11-14 20:50:43',NULL),(16,'LDA-20261115-0002','Ratna Juwita','ratna.juwita@unair.ac.id','081552334402','081552334402','3578166010960016','1996-10-20','Universitas Airlangga (UNAIR)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,4,'2026-11-15 02:34:27','lost',9,'Respon prospek: Tidak Tertarik. Belum ada kebutuhan pelatihan saat ini.',0,'normal','2026-11-15 03:51:25','2026-11-15 04:15:38',NULL,'2026-11-15 04:15:38','Penjajakan kerja sama pelatihan staf tendik','2026-11-14 19:34:27','2026-11-14 21:15:38',NULL),(17,'LDA-20261115-0003','Kevin Sanjaya Putra','kevin.sanjaya@wingscorp.com','081552334403','081552334403','3578170203950017','1995-03-02','PT Wings Surya Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,4,'2026-11-15 02:34:27','lost',6,'Respon prospek: Nomor Salah. Calon peserta dapat di-follow up ulang di masa mendatang.',0,'normal','2026-11-15 04:07:19','2026-11-15 04:07:19',NULL,'2026-11-15 04:07:19','Kebutuhan pelatihan corporate sales','2026-11-14 19:34:27','2026-11-14 21:07:19',NULL),(18,'LDA-20261115-0004','Anisa Rahmawati','anisa.rahmawati@unesa.ac.id','081552334404','081552334404','3578184511970018','1997-11-05','Universitas Negeri Surabaya (UNESA)',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,4,'2026-11-15 02:34:27','won',NULL,NULL,0,'normal','2026-11-15 04:22:29','2026-11-15 04:22:29','2026-11-15 04:31:38',NULL,'Menunggu penawaran harga rombongan','2026-11-14 19:34:27','2026-11-14 21:31:38',NULL),(19,'LDA-20261115-0005','Galang Fajar Kurnia','galang.fajar@maspion.com','081552334405','081552334405','3578191107930019','1993-07-11','Maspion Group Indonesia',NULL,'Sidoarjo','Jawa Timur',NULL,2,NULL,NULL,4,'2026-11-15 02:34:27','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Minta presentasi online dari tim sales','2026-11-14 19:34:27','2026-11-14 19:34:27',NULL),(20,'LDA-20261115-0006','Putri Ayu Maharani','putri.ayu@ubaya.ac.id','081552334406','081552334406','3578205409980020','1998-09-14','Universitas Surabaya (UBAYA)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,4,'2026-11-15 02:34:27','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Follow up jadwal pendaftaran batch berikutnya','2026-11-14 19:34:27','2026-11-14 19:34:27',NULL),(21,'LDA-20261115-0007','Yudha Pratama Wicaksono','yudha.pratama@pakuwon.com','081552334407','081552334407','3578213005910021','1991-05-30','PT Pakuwon Jati Tbk',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,4,'2026-11-15 02:34:27','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Belum tentukan program pelatihan yang diambil','2026-11-14 19:34:27','2026-11-14 19:34:27',NULL),(22,'LDA-20261115-0008','huni','huni@gmail.com','085812304685','085812304685','3517085909040001','2008-07-15','Universitas Indonesia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,NULL,'2026-11-15 07:50:14','2026-11-15 07:50:14',NULL),(23,'LDA-20261115-0009','sadam','sadam@gmail.com','085812304685','085812304685','3517085909040001','2026-11-17','Universitas Lampung',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:02:17','2026-11-15 08:02:17',NULL),(24,'LDA-20261115-0010','julia','julia@gmail.com','085812304685','085812304685','3517085909040001','2026-11-20','Universitas Kartika',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:03:16','2026-11-15 08:03:16',NULL),(25,'LDA-20261115-0011','roman','roman@gmail.com','085812304685','085812304685','3517085909040001','2026-11-04','Universitas bangka',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,'new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:15:35','2026-11-15 08:15:35',NULL),(26,'LDA-20261115-0012','Dimas Arya Pamungkas','dimas.arya@its.ac.id','081552334401','081552334401','3578151908940015','1994-08-19','Institut Teknologi Sepuluh Nopember (ITS)',NULL,'Surabaya','Jawa Timur',NULL,2,1,4273500.00,2,'2026-11-15 15:33:08','lost',8,'Respon prospek: Tidak Bersedia. Dapat di-follow up ulang di masa depan.',0,'normal','2026-11-16 11:29:41','2026-11-16 11:29:41',NULL,'2026-11-16 11:29:41','Prospek kampus, menanyakan akreditasi pelatihan','2026-11-15 08:33:08','2026-11-16 04:29:41',NULL),(27,'LDA-20261115-0013','Ratna Juwita','ratna.juwita@unair.ac.id','081552334402','081552334402','3578166010960016','1996-10-20','Universitas Airlangga (UNAIR)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Penjajakan kerja sama pelatihan staf tendik','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL),(28,'LDA-20261115-0014','Kevin Sanjaya Putra','kevin.sanjaya@wingscorp.com','081552334403','081552334403','3578170203950017','1995-03-02','PT Wings Surya Surabaya',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Kebutuhan pelatihan corporate sales','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL),(29,'LDA-20261115-0015','Anisa Rahmawati','anisa.rahmawati@unesa.ac.id','081552334404','081552334404','3578184511970018','1997-11-05','Universitas Negeri Surabaya (UNESA)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Menunggu penawaran harga rombongan','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL),(30,'LDA-20261115-0016','Galang Fajar Kurnia','galang.fajar@maspion.com','081552334405','081552334405','3578191107930019','1993-07-11','Maspion Group Indonesia',NULL,'Sidoarjo','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Minta presentasi online dari tim sales','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL),(31,'LDA-20261115-0017','Putri Ayu Maharani','putri.ayu@ubaya.ac.id','081552334406','081552334406','3578205409980020','1998-09-14','Universitas Surabaya (UBAYA)',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Follow up jadwal pendaftaran batch berikutnya','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL),(32,'LDA-20261115-0018','Yudha Pratama Wicaksono','yudha.pratama@pakuwon.com','081552334407','081552334407','3578213005910021','1991-05-30','PT Pakuwon Jati Tbk',NULL,'Surabaya','Jawa Timur',NULL,2,NULL,NULL,2,'2026-11-15 15:33:08','new',NULL,NULL,0,'normal',NULL,NULL,NULL,NULL,'Belum tentukan program pelatihan yang diambil','2026-11-15 08:33:08','2026-11-15 08:33:08',NULL);
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;

--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_10_22_000001_create_products_table',1),(5,'2026_10_22_000002_create_lead_sources_table',1),(6,'2026_10_22_000003_create_rejection_reasons_table',1),(7,'2026_10_22_000004_create_leads_table',1),(8,'2026_10_22_000005_create_activities_table',1),(9,'2026_10_22_000006_create_follow_ups_table',1),(10,'2026_10_22_000007_create_payments_table',1),(11,'2026_10_22_000008_create_commissions_table',1),(12,'2026_10_22_000009_create_import_tables',1),(13,'2026_10_22_000010_create_institutions_table',1),(14,'2026_10_22_000011_create_customers_table',1),(15,'2026_10_22_000012_create_trainers_table',1),(16,'2026_10_22_000013_create_training_schedules_table',1),(17,'2026_10_22_000014_create_registrations_table',1),(18,'2026_11_02_000001_add_deal_price_to_leads_table',2),(19,'2026_11_02_000002_create_sales_reminders_table',3),(20,'2026_11_02_000003_add_type_and_commission_to_sales_reminders_table',4),(21,'2019_12_14_000001_create_personal_access_tokens_table',5),(22,'2026_11_05_000001_add_product_type_to_products_table',5),(23,'2026_11_14_000001_add_nik_and_birth_date_to_leads_table',6),(24,'2026_11_14_000002_add_nik_and_birth_date_to_customers_table',7),(25,'2026_11_14_163030_add_bank_account_to_users_table',8),(26,'2026_11_14_170047_add_bank_snapshot_to_commissions_table',9),(27,'2026_11_15_000001_add_user_id_to_registrations_table',10);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

--
-- Table structure for table `password_reset_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `proof_file` varchar(255) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `verification_notes` text DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_product_id_foreign` (`product_id`),
  KEY `payments_verified_by_foreign` (`verified_by`),
  KEY `payments_lead_id_index` (`lead_id`),
  KEY `payments_status_index` (`status`),
  KEY `payments_payment_date_index` (`payment_date`),
  CONSTRAINT `payments_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,3,NULL,1,1831500.00,NULL,'BCA','5420192811','Hendra Gunawan','payments/to1pp7QQzoAMJxSlW9qkpsWbHxr2bQAo0edZm9UV.jpg','2026-11-14 00:00:00','valid','Diverifikasi valid: Transaksi disetujui dan komisi telah dicairkan.','2026-11-14 14:01:38','Transfer pelatihan Rp 1.665.000 + komisi sales 10% (Rp 166.500) = Rp 1.831.500','2026-11-14 06:39:23','2026-11-14 07:10:02'),(10,2,1,1,4273500.00,NULL,'BCA',NULL,'Dwi Lestari Wulandari','payments/C92JXXoiwc5R4Je0qYB8Tqvg8Hpjn3K1F6aN37Ic.jpg',NULL,'valid',NULL,'2026-11-14 16:06:24',NULL,'2026-11-14 08:25:06','2026-11-14 09:06:24'),(11,4,1,1,4273500.00,NULL,'BCA',NULL,'Maya Anggraini','payments/nR9LlNPijQJAyaMJVQYBsL8rPg42uUAyluq8y0Dz.avif',NULL,'valid',NULL,'2026-11-14 16:18:12',NULL,'2026-11-14 09:17:47','2026-11-14 09:18:12'),(12,5,2,1,1831500.00,NULL,'BCA',NULL,'Bagus Setiawan','payments/c24NiWBOSXN7yJK6IdjNqsfnnUffqFzNgxDX04Sz.jpg',NULL,'valid',NULL,'2026-11-14 16:56:22',NULL,'2026-11-14 09:56:08','2026-11-14 09:56:22'),(13,8,1,1,4273500.00,NULL,'BCA',NULL,'Fajar Ramadhan','payments/0eRGP6oaKYWUJjMIkyxejzI6Uoso7s7agn1tVR5b.jpg',NULL,'valid','Test verify','2026-11-14 19:26:33',NULL,'2026-11-14 12:21:18','2026-11-14 12:26:33'),(14,15,2,1,1831500.00,NULL,'BCA',NULL,'Dimas Arya Pamungkas','payments/j5nESNXbq9sN6Nd5Mq7JuYVhjKwDU6lzcwHpqkXN.jpg',NULL,'valid',NULL,'2026-11-15 03:44:47',NULL,'2026-11-14 20:34:04','2026-11-14 20:44:47'),(15,18,1,1,4273500.00,NULL,'BCA',NULL,'Anisa Rahmawati','payments/lwivSDPxyqLVYEeFsPm3L7cHM3BidaQ2TDG51VMm.jpg',NULL,'valid','Transfer BCA valid dan sudah masuk rekening Disty Akademi.','2026-11-15 04:31:38',NULL,'2026-11-14 21:23:27','2026-11-14 21:31:38'),(16,9,1,1,4273500.00,NULL,'BCA',NULL,'Nurul Hidayati','payments/plpU6xvs0elwyykad8EDfblcoq362RhTL81j2ZUA.jpg',NULL,'valid',NULL,'2026-11-15 15:55:35',NULL,'2026-11-15 08:51:37','2026-11-15 08:55:35'),(17,1,1,1,4273500.00,NULL,'BCA',NULL,'Dimas Arya Pamungkas','payments/LkVlnXCacaaqEjiKQroENzjvmus9wFUA0ufdl7O9.jpg',NULL,'valid',NULL,'2026-11-16 11:28:11',NULL,'2026-11-16 04:27:57','2026-11-16 04:28:11'),(19,4,3,1,976800.00,NULL,'BCA',NULL,'Maya Anggraini',NULL,NULL,'valid',NULL,'2026-11-16 12:13:56',NULL,'2026-11-16 05:12:42','2026-11-16 05:36:13'),(20,15,1,NULL,4273500.00,NULL,'BCA',NULL,'Dimas Arya Pamungkas','payments/wC5bZAR2hzDbO9QLNyW9IFmnx1gbfzCrTyzqQLlj.jpg',NULL,'pending',NULL,NULL,NULL,'2026-11-22 08:04:16','2026-11-22 08:04:16');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;

--
-- Table structure for table `personal_access_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `product_type` varchar(30) NOT NULL DEFAULT 'training',
  `price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `duration_hours` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_code_unique` (`code`),
  KEY `products_category_index` (`category`),
  KEY `products_is_active_index` (`is_active`),
  KEY `products_product_type_index` (`product_type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Pelatihan dan Sertifikasi Digital Filing','PRD-DF','Pelatihan dan Sertifikasi Digital Filing dirancang untuk membekali peserta dengan keterampilan mengelola, menyimpan, dan menata dokumen secara digital secara efektif, aman, dan efisien sesuai kebutuhan instansi dan organisasi modern. Harga sudah termasuk: Pelatihan Digital Filing, Sertifikat Peserta, Konsumsi Peserta, Transportasi Trainer, Akomodasi Trainer, Pajak.','Pelatihan & Sertifikasi','bundle',3885000.00,24,1,'2026-10-22 07:18:55','2026-11-14 01:43:46',NULL),(2,'Pelatihan Pelayanan Prima','PRD-PP','Pelatihan Pelayanan Prima dirancang untuk meningkatkan pengetahuan, keterampilan, dan sikap peserta dalam memberikan pelayanan yang efektif, ramah, profesional, dan berorientasi pada kepuasan pelanggan. Harga sudah termasuk: Pelatihan, Materi Pelatihan, Konsumsi Peserta, Transportasi Trainer, Akomodasi Trainer.','Pelatihan','training',1665000.00,16,1,'2026-10-22 07:18:55','2026-11-14 01:43:46',NULL),(3,'Sertifikasi Pelayanan Prima (Excellent Service) Lisensi BNSP','BNSP-ES','Sertifikasi BNSP untuk Skema Pelayanan Prima (Excellent Service) berdasarkan SKKNI Bidang Administratif Profesional. Fasilitas: Harga sudah termasuk pajak, Harga belum termasuk makan, minum dan tempat, Asesmen oleh Asesor yang kompeten sesuai bidangnya, Materi Uji Kompetensi versi 2023, Sertifikat Kompetensi BNSP (bagi yang telah mengikuti asesmen dan direkomendasikan kompeten).','Sertifikasi BNSP','certification',888000.00,16,1,'2026-10-22 07:18:55','2026-11-14 01:43:46',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

--
-- Table structure for table `registrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `registration_number` varchar(100) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `training_schedule_id` bigint(20) unsigned DEFAULT NULL,
  `training_date` date DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'registered',
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `registrations_registration_number_unique` (`registration_number`),
  KEY `registrations_customer_id_index` (`customer_id`),
  KEY `registrations_product_id_index` (`product_id`),
  KEY `registrations_training_schedule_id_index` (`training_schedule_id`),
  KEY `registrations_status_index` (`status`),
  KEY `registrations_user_id_foreign` (`user_id`),
  CONSTRAINT `registrations_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `registrations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `registrations_training_schedule_id_foreign` FOREIGN KEY (`training_schedule_id`) REFERENCES `training_schedules` (`id`) ON DELETE SET NULL,
  CONSTRAINT `registrations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
INSERT INTO `registrations` VALUES (1,'REG-20261114-0001',1,NULL,1,NULL,NULL,'confirmed',3885000.00,NULL,'2026-11-14 05:57:44','2026-11-16 04:28:11'),(2,'REG-20261114-0002',2,NULL,2,NULL,NULL,'confirmed',1831500.00,NULL,'2026-11-14 06:03:59','2026-11-14 12:19:15'),(3,'REG-20261114-0003',3,NULL,1,NULL,NULL,'confirmed',4273500.00,NULL,'2026-11-14 08:10:53','2026-11-14 12:19:15'),(4,'REG-20261114-0004',4,NULL,1,1,'2026-11-15','confirmed',4273500.00,NULL,'2026-11-14 09:17:17','2026-11-14 12:19:15'),(5,'REG-20261114-0005',5,NULL,2,NULL,NULL,'confirmed',1831500.00,NULL,'2026-11-14 09:55:52','2026-11-14 09:56:22'),(6,'REG-20261114-0006',6,NULL,1,1,'2026-11-15','confirmed',4273500.00,NULL,'2026-11-14 12:20:57','2026-11-14 12:26:33'),(7,'REG-20261115-0001',7,4,2,NULL,NULL,'confirmed',1831500.00,NULL,'2026-11-14 20:33:46','2026-11-14 20:44:38'),(8,'REG-20261115-0002',8,4,1,1,'2026-11-15','confirmed',4273500.00,NULL,'2026-11-14 21:23:02','2026-11-14 21:31:38'),(9,'REG-20261115-0003',9,3,1,1,'2026-11-15','confirmed',4273500.00,NULL,'2026-11-15 08:51:06','2026-11-15 08:55:35'),(10,'REG-20261116-0001',7,2,1,1,'2026-11-15','registered',4273500.00,NULL,'2026-11-16 04:27:33','2026-11-16 05:06:04'),(11,'REG-20261116-0002',4,2,3,NULL,NULL,'confirmed',976800.00,NULL,'2026-11-16 04:30:24','2026-11-16 05:13:56');
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;

--
-- Table structure for table `rejection_reasons`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rejection_reasons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rejection_reasons_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rejection_reasons`
--

/*!40000 ALTER TABLE `rejection_reasons` DISABLE KEYS */;
INSERT INTO `rejection_reasons` VALUES (1,'too_expensive','Harga Terlalu Mahal',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(2,'wrong_timing','Waktu Pelatihan Tidak Cocok',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(3,'no_budget','Belum Ada Anggaran Kantor',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(4,'competitor','Memilih Vendor Lain',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(5,'no_response','Tidak Merespon Chat/Telp',NULL,1,'2026-10-22 07:18:55','2026-10-22 07:18:55'),(6,'wrong_number','Nomor Salah',NULL,1,'2026-11-14 00:31:59','2026-11-14 00:31:59'),(7,'unreachable','Tidak Dapat Dihubungi',NULL,1,'2026-11-14 00:31:59','2026-11-14 00:31:59'),(8,'not_willing','Tidak Bersedia',NULL,1,'2026-11-14 00:31:59','2026-11-14 00:31:59'),(9,'not_interested','Tidak Tertarik',NULL,1,'2026-11-14 00:31:59','2026-11-14 00:31:59');
/*!40000 ALTER TABLE `rejection_reasons` ENABLE KEYS */;

--
-- Table structure for table `sales_reminders`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` bigint(20) unsigned NOT NULL,
  `commission_id` bigint(20) unsigned DEFAULT NULL,
  `admin_id` bigint(20) unsigned NOT NULL,
  `sales_id` bigint(20) unsigned NOT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'follow_up',
  `message` text NOT NULL,
  `priority` varchar(20) NOT NULL DEFAULT 'urgent',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT 0,
  `completed_at` timestamp NULL DEFAULT NULL,
  `sales_reply` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_reminders_admin_id_foreign` (`admin_id`),
  KEY `sales_reminders_sales_id_is_completed_index` (`sales_id`,`is_completed`),
  KEY `sales_reminders_sales_id_is_read_index` (`sales_id`,`is_read`),
  KEY `sales_reminders_lead_id_index` (`lead_id`),
  KEY `sales_reminders_commission_id_foreign` (`commission_id`),
  CONSTRAINT `sales_reminders_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_reminders_commission_id_foreign` FOREIGN KEY (`commission_id`) REFERENCES `commissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_reminders_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_reminders_sales_id_foreign` FOREIGN KEY (`sales_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_reminders`
--

/*!40000 ALTER TABLE `sales_reminders` DISABLE KEYS */;
INSERT INTO `sales_reminders` VALUES (2,3,1,1,2,'commission_paid','Selamat! Komisi 10% sebesar Rp 166.500 untuk prospek Hendra Gunawan (Total transfer customer: Rp 1.831.500) telah berhasil ditransfer pada 14 Nov 2026, 20:41 WIB (Ref Mutasi: 81978000).','normal',1,'2026-11-14 06:55:45',1,NULL,NULL,'2026-11-14 06:42:04','2026-11-14 07:10:02'),(3,2,2,1,2,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Dwi Lestari Wulandari telah berhasil ditransfer pada 14 Nov 2026, 22:54 WIB.','normal',1,'2026-11-14 08:55:01',1,NULL,NULL,'2026-11-14 08:54:34','2026-11-14 08:55:01'),(4,4,3,1,2,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Maya Anggraini telah berhasil ditransfer pada 14 Nov 2026, 23:18 WIB (Ref Mutasi: 8889990000).','normal',1,'2026-11-14 09:19:20',1,NULL,NULL,'2026-11-14 09:19:09','2026-11-14 09:19:20'),(5,5,4,1,2,'commission_paid','Selamat! Komisi 10% sebesar Rp 166.500 untuk prospek Bagus Setiawan telah berhasil ditransfer pada 15 Nov 2026, 00:12 WIB.','normal',1,'2026-11-14 11:45:17',1,NULL,NULL,'2026-11-14 10:12:12','2026-11-14 11:45:17'),(6,8,5,1,3,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Fajar Ramadhan telah berhasil ditransfer pada 15 Nov 2026, 02:21 WIB.','normal',1,'2026-11-14 12:22:03',1,NULL,NULL,'2026-11-14 12:21:42','2026-11-14 12:22:03'),(7,15,NULL,1,4,'payment_rejected','Bukti pembayaran peserta Dimas Arya Pamungkas dinyatakan TIDAK VALID oleh Admin. Alasan: \"bukti palsu\". Silakan hubungi peserta untuk konfirmasi ulang bukti transfer yang sah.','urgent',1,'2026-11-14 20:44:17',1,'2026-11-14 20:44:38','Selesai: Pembayaran terverifikasi valid','2026-11-14 20:43:07','2026-11-14 20:44:38'),(8,15,NULL,1,4,'payment_rejected','Bukti pembayaran peserta Dimas Arya Pamungkas dinyatakan TIDAK VALID oleh Admin. Alasan: \"bukti palsu\". Silakan hubungi peserta untuk konfirmasi ulang bukti transfer yang sah.','urgent',1,'2026-11-14 20:44:16',1,'2026-11-14 20:44:38','Selesai: Pembayaran terverifikasi valid','2026-11-14 20:43:53','2026-11-14 20:44:38'),(9,15,7,1,4,'commission_paid','Selamat! Komisi 10% sebesar Rp 166.500 untuk prospek Dimas Arya Pamungkas telah berhasil ditransfer pada 15 Nov 2026, 10:45 WIB.','normal',1,'2026-11-14 20:45:19',1,NULL,NULL,'2026-11-14 20:45:02','2026-11-14 20:45:19'),(10,18,8,1,4,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Anisa Rahmawati telah berhasil ditransfer pada 15 Nov 2026, 11:32 WIB.','normal',1,'2026-11-14 21:32:39',1,NULL,NULL,'2026-11-14 21:32:21','2026-11-14 21:32:39'),(11,9,9,1,3,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Nurul Hidayati telah berhasil ditransfer pada 15 Nov 2026, 22:55 WIB.','normal',0,NULL,1,NULL,NULL,'2026-11-15 08:56:07','2026-11-15 08:56:07'),(12,26,NULL,1,2,'follow_up','Mohon segera tindak lanjuti prospek \"Dimas Arya Pamungkas\" (WA: 081552334401) untuk penawaran program Program Pelatihan. Berikan detail materi dan jadwal pelatihan terdekat.','urgent',1,'2026-11-16 00:07:34',1,'2026-11-16 04:29:41','Respon prospek: Tidak Bersedia. Dapat di-follow up ulang di masa depan.','2026-11-16 00:07:01','2026-11-16 04:29:41'),(13,1,10,1,2,'commission_paid','Selamat! Komisi 10% sebesar Rp 388.500 untuk prospek Mochammad Rizky Pratama telah berhasil ditransfer pada 16 Nov 2026, 18:28 WIB.','normal',1,'2026-11-16 04:28:39',1,NULL,NULL,'2026-11-16 04:28:24','2026-11-16 04:28:39');
/*!40000 ALTER TABLE `sales_reminders` ENABLE KEYS */;

--
-- Table structure for table `sessions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trainers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trainers_name_is_active_index` (`name`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainers`
--

/*!40000 ALTER TABLE `trainers` DISABLE KEYS */;
INSERT INTO `trainers` VALUES (1,'Drs. Purwanto, M.Si.','purwanto@distyakademi.com','081112220000','Trainer profesional resmi Disty Akademi',1,'2026-10-22 07:18:55','2026-11-14 02:40:34'),(2,'Drs. Mochammad Saleh, M.Si.','mochammad.saleh@distyakademi.com','082224440000','Trainer profesional resmi Disty Akademi',1,'2026-10-22 07:18:55','2026-11-14 02:40:34'),(3,'Bayu Pancoroadi, ST.,MT','bayu.pancoroadi@distyakademi.com','083336660000','Trainer profesional resmi Disty Akademi',1,'2026-10-22 07:18:55','2026-11-14 02:40:34'),(4,'Miftahul Ulum, ST., M.Si.','miftahul.ulum@distyakademi.com','084448880000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(5,'Mochamad Samsukadi, Lc., M.Th.I','mochamad.samsukadi@distyakademi.com','085561100000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(6,'Galuh Tisna Widiana, M.Pd.','galuh.tisna@distyakademi.com','086673320000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(7,'M. Yusuf Wibowo, ST.','yusuf.wibowo@distyakademi.com','087785540000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(8,'M. Ali Murtadlo, M.Kom.','ali.murtadlo@distyakademi.com','088897760000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(9,'Chandra Sukma Anugrah, M.Kom.','chandra.sukma@distyakademi.com','081000998000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(10,'Wiwit Denny Fitriana, M.Si.','wiwit.denny@distyakademi.com','081112220000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(11,'Dr. Nur Ulwiyah, M.Pd.I','nur.ulwiyah@distyakademi.com','081223442000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(12,'Dr. Miftakhul Ilmi S. Putra, M.Pd.','miftakhul.ilmi@distyakademi.com','081334664000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(13,'Dr. Dhikrul Hakim, M.Pd.I','dhikrul.hakim@distyakademi.com','081445886000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(14,'Dr. Moh. Makmun, M.HI','moh.makmun@distyakademi.com','081557108000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34'),(15,'Mahmud Huda, M.S.I','mahmud.huda@distyakademi.com','081668330000','Trainer profesional resmi Disty Akademi',1,'2026-11-14 02:37:58','2026-11-14 02:40:34');
/*!40000 ALTER TABLE `trainers` ENABLE KEYS */;

--
-- Table structure for table `training_schedules`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `trainer_id` bigint(20) unsigned NOT NULL,
  `training_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `capacity` int(10) unsigned NOT NULL DEFAULT 20,
  `status` varchar(30) NOT NULL DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `training_schedules_product_id_training_date_index` (`product_id`,`training_date`),
  KEY `training_schedules_trainer_id_training_date_index` (`trainer_id`,`training_date`),
  KEY `training_schedules_status_index` (`status`),
  CONSTRAINT `training_schedules_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `training_schedules_trainer_id_foreign` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_schedules`
--

/*!40000 ALTER TABLE `training_schedules` DISABLE KEYS */;
INSERT INTO `training_schedules` VALUES (1,1,4,'2026-11-15','09:00:00','10:00:00','Disty Academy Hall / Zoom Meeting',25,'scheduled',NULL,'2026-11-14 09:16:16','2026-11-14 09:16:16'),(2,2,7,'2026-11-17','09:00:00','16:00:00','Disty Academy Hall / Zoom Meeting',25,'scheduled',NULL,'2026-11-15 09:53:41','2026-11-15 09:53:41');
/*!40000 ALTER TABLE `training_schedules` ENABLE KEYS */;

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'sales',
  `phone` varchar(50) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `bank_account_number` varchar(50) DEFAULT NULL,
  `bank_account_name` varchar(150) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_index` (`role`),
  KEY `users_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin CRM','admin@distyakademi.com',NULL,'$2y$12$wkpcsL4KdE0tERPyN9mlMO9P7OQbNHmcy5/QCeDlG5y6kdVsN5EHi','admin',NULL,NULL,NULL,NULL,1,NULL,'2026-10-22 07:18:55','2026-10-22 07:18:55',NULL),(2,'Budi Santoso','budi@distyakademi.com',NULL,'$2y$12$2hNf.fKVCcztZQ11oOQPT.KfyO84d1YFpTINv/bZenEr28/4RIp66','sales','081234567890','BNI','883019281','Budi Santoso',1,NULL,'2026-10-22 07:18:55','2026-11-14 09:55:22',NULL),(3,'Sari Dewi','sari@distyakademi.com',NULL,'$2y$12$5hk2abY9WnrY12X7FeLatOx/MkuixhLgRy6LbQPH/JstuH4rY5Q.2','sales','081234567891','Bank Mandiri','141002938192','Sari Dewi',1,NULL,'2026-10-22 07:18:55','2026-10-22 07:18:55',NULL),(4,'Andi Wijaya','andi@distyakademi.com',NULL,'$2y$12$fuZHUQlL8aovQTPqsSoYeep7hF0tyvuiKo6btS7UjglAyhrs8eFti','sales','081234567892','BNI','0928371928','Andi Wijaya',1,NULL,'2026-10-22 07:18:55','2026-10-22 07:18:55',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-22 22:12:25
